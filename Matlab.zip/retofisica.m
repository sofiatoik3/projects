clear
%%%%%%%%%%
angulo=randi([5,90]);
velocidadinicial=randi([200,300]);
count=0;
valorderiesgo=zeros(1,40);
valory=zeros(1,40);
zona1=0
Zona2=0
Zona3=0
Zona4=0
Zona5=0
Zona6=0
Zona7=0
Zona8=0
Zona9=0

while count<40
    count=movprojectile(angulo,velocidadinicial,count)
    count=count
    posicionx=movprojectile2(angulo,velocidadinicial)
    valorderiesgo(count)=posicionx;
    angulo=randi([5,45]);
    velocidadinicial=randi([200,300]);
end
k=(1:1000)
valor=0
peligro=zeros(1,8)
for i=k
    valor=valorderiesgo(i);
    if (valor > 1000) &  (valor<2500)
        zona1=zona1+1;
        peligro(1)=zona1
    elseif (valor > 2500) & (valor<4000)
        Zona2=Zona2+1;
        peligro(2)=Zona2
    elseif (valor > 4000) & (valor<5500)
        Zona3=Zona3+1;
        peligro(3)=Zona3
    elseif (valor > 5500) & (valor<7000)
        Zona4=Zona4+1;
        peligro(4)=Zona4
    elseif (valor > 7000) & (valor<8500)
        Zona5=Zona5+1;
        peligro(5)=Zona5
   elseif (valor > 8500) & (valor<10000)
        Zona6=Zona6+1;
        peligro(6)=Zona6
    elseif (valor > 10000) & (valor<11500)
        Zona7=Zona7+1;
        peligro(7)=Zona7
    elseif (valor > 11500) & (valor<13000)
        Zona8=Zona8+1;
        peligro(8)=Zona8
    elseif (valor > 13000) & (valor<14500)
        Zona9=Zona9+1;
        peligro(9)=Zona9
    end
    
maximun=max(peligro)
minumun=min(peligro)
end
    
function [count]=movprojectile(angulo,velocidadinicial,count)
gravedad=-9.81;
altura=3350;
densidadair=1.003;
masa=3000;
Area=.25;
coeficienteaire=0.47;
b=((Area*densidadair*coeficienteaire)/2);
v0x = velocidadinicial*cosd(angulo);
v0y=velocidadinicial*(sind(angulo));
paso=.1;
t=0:paso:70;
x=length(t)
%%vectores de salida
sx=zeros(1,x);%vector de posicion res
vx=zeros(1,x);%vector de velocidad res
vy=zeros(1,x);%vector de velocidad res
ax=zeros(1,x);%vector de aceleracion res
ay=zeros(1,x);%vector de aceleracion res
%valores iniciales
ay(1)=gravedad-1*((b/masa)*v0y^(2));
vy(1)=v0y;
sy(1)=altura;

%%%calculo
    for k = 2:length(t)
        ay(k)=gravedad-(b*vy(k-1)^(2))/masa;
        vy(k)=vy(k-1)+paso*ay(k-1);
        sy(k)=sy(k-1)+paso*vy(k-1);
    end
    

 %%graficar 
ax(1)=-1*((b*v0x^(2))/masa);
vx(1)=v0x;
sx(1)=0;
   for k = 2:length(t)
        ax(k)=-1*(b*vx(k-1).^(2))/masa;
        vx(k)=vx(k-1)+paso.*ax(k-1);
        sx(k)=sx(k-1)+paso.*vx(k-1);
   end

  vy=1:2500;
  vz=-(1.5).*vy+3350;
   hold on
   plot(vy,vz)
   plot (sx,sy)
   ylim([0 7000])
   count=count+1
end

function [posicionx]=movprojectile2(angulo,velocidadinicial)
gravedad=-9.81;
altura=3350;
densidadair=1.003;
masa=3000;
Area=.25;
coeficienteaire=0.47;
b=((Area*densidadair*coeficienteaire)/2);
v0x = velocidadinicial*cosd(angulo);
v0y=velocidadinicial*(sind(angulo));
paso=.1;
t=0:paso:70;
x=length(t)

%%vectores de salida
sx=zeros(1,x);%vector de posicion res
vx=zeros(1,x);%vector de velocidad res
vy=zeros(1,x);%vector de velocidad res
ax=zeros(1,x);%vector de aceleracion res
ay=zeros(1,x);%vector de aceleracion res

%valores iniciales
ay(1)=gravedad-1*((b/masa)*v0y^(2));
vy(1)=v0y;
sy(1)=altura;
 
%%%calculo
    for k = 2:length(t)
        ay(k)=gravedad-(b*vy(k-1)^(2))/masa;
        vy(k)=vy(k-1)+paso*ay(k-1);
        sy(k)=sy(k-1)+paso*vy(k-1);

    end
    
 %%graficar  
ax(1)=-1*((b*v0x^(2))/masa);
vx(1)=v0x;
sx(1)=0;
   for k = 2:length(t)
        ax(k)=-1*(b*vx(k-1).^(2))/masa;
        vx(k)=vx(k-1)+paso.*ax(k-1);
        sx(k)=sx(k-1)+paso.*vx(k-1);
   
   
   end
  
  diferencia=abs(sy-0);
   posiciondis=find(diferencia==min(diferencia));
   posicionx=sx(posiciondis); 
end 