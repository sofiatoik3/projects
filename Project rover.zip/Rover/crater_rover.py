import numpy as np
import time
import random
import math
import plotly.graph_objects as px 

start_time = time.time()

crater_map = np.load('crater_map.npy')
nr, nc = crater_map.shape



class Coord(object):
    
    def __init__(self, state, map):
        self.state = state
        self.map = map
        
    def nearestNeighbor(self):
        
        listV = [-1,0,1,0,-1,-1,1,1]
        listH = [0,1,0,-1,-1,1,-1,1]
        
        r,c= self.state
        maxHeight = 2.0
        
        neighborList = []
        #neighbor = Coord(state, map)
        
        for i in range(len(listH)):
            new_y = r + listV[i]
            new_x = c + listH[i]
            if ((abs(self.map[new_y][new_x]-self.map[r,c])) <= maxHeight) and (self.map[new_y][new_x] != -1):
                neighborList.append(Coord((new_y, new_x), self.map))
                
        return neighborList
    
    def cost(self):
        
        x1 = self.state[1]
        y1 = self.state[0]
        cost = self.map[y1][x1]
        
        return cost
        
                #neighbor.state[0] = new_y
                #neighbor.state[1] = new_x
                #return neighbor
            #else:
            #    return None
                

random.seed(time.time()*1000)
                
scale = 10.045

#xi = 3350
#yi = 5800

#xi = 3957
#yi = 4962

#xi = 3335
#yi = 3978

#xi = 4480
#yi = 4279

#xi = 2159
#yi = 5424

xi = 2240
yi = 4550

ri = nr - round(yi/scale)
ci = round(xi/scale)

initial_state = (ri,ci)

coord = Coord(initial_state, crater_map)
cost = coord.cost()

step = 0                    # Step count

alpha = 0.9995              # Coefficient of the exponential temperature schedule        
t0 = 10                      # Initial temperature
t = t0 

listX = []
listY = []
listZ = []


while t > 0.1 and cost > 0:
    t = t0 * math.pow(alpha, step)
    step += 1
    neighborList = coord.nearestNeighbor() 
    neighbor = random.choice(neighborList)
    new_cost = neighbor.cost()
    
    
    if new_cost < cost:
        coord = neighbor
        cost = new_cost
        listX.append(coord.state[1])
        listY.append(coord.state[0])
        listZ.append(crater_map[coord.state[0]][coord.state[1]])
        print('Posición: ', coord.state[1], coord.state[0], 'Costo: ', cost)
        
                
    else:
        # Calculate probability of accepting the neighbor
        p = math.exp(-(new_cost - cost)/t)
        if p >= random.random():
            coord = neighbor
            cost = new_cost
            listX.append(coord.state[1])
            listY.append(coord.state[0])
            listZ.append(crater_map[coord.state[0]][coord.state[1]])
            print('Posición: ', coord.state[1], coord.state[0], 'Costo: ', cost)
            


for i in range (len(listX)):
    listX[i] = listX[i]*scale
    
for i in range (len(listY)):
    listY[i] = (nr-listY[i])*scale

x = scale*np.arange(crater_map.shape[1])
y = scale*np.arange(crater_map.shape[0])
X, Y = np.meshgrid(x, y)

fig = px.Figure(data = [px.Surface(x=X, y=Y, z=np.flipud(crater_map), colorscale='hot', cmin = 0, 
                           lighting = dict(ambient = 0.0, diffuse = 0.8, fresnel = 0.02, roughness = 0.4, specular = 0.2), 
                           lightposition=dict(x=0, y=nr/2, z=2*crater_map.max())),

                        px.Scatter3d(x = listX, y = listY, z = listZ, name='path', mode='markers',
                                    marker=dict(color = np.linspace(0, 1, len(listX)), colorscale='Bluered', size=4))],
                
                layout = px.Layout(scene_aspectmode='manual', 
                                   scene_aspectratio=dict(x=1, y=nr/nc, z=max((crater_map.max())/x.max(), 0.2)), 
                                   scene_zaxis_range = [0,crater_map.max()])
                )

fig.show()












