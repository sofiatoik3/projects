import numpy as np
from simpleai.search import astar, SearchProblem, breadth_first, depth_first, greedy, uniform_cost
import plotly.graph_objects as px 
import time

start_time = time.time()


mars_map = np.load('mars_map.npy')
nr, nc = mars_map.shape


class RoverSearch(SearchProblem):
    
#   listV = [-1,0,1,0,-1,-1,1,1]
#   listH = [0,1,0,-1,-1,1,-1,1]
    
    
    def __init__(self, initial_state, goal_state, map):
        SearchProblem.__init__(self, initial_state)
                
        self.goal = goal_state
        self.map = map
        
    def actions(self, state):
        
        altMax = 0.25
        r,c=state       
        actions = []
        
        if (abs(self.map[r+1][c] - self.map[r,c]) <= altMax ) and (self.map[r+1][c] != -1): #Abajo            
            actions.append((r+1,c))
            
        if (abs(self.map[r][c-1] - self.map[r,c]) <= altMax ) and (self.map[r][c-1]!= -1): #Izquierda            
            actions.append((r,c-1))
            
        if (abs(self.map[r][c+1] - self.map[r,c]) <= altMax ) and (self.map[r][c+1]!= -1): #Derecha            
            actions.append((r,c+1))
            
        if (abs(self.map[r-1][c] - self.map[r,c]) <= altMax ) and (self.map[r-1][c]!= -1): # Arriba            
            actions.append((r-1,c))
            
        if (abs(self.map[r+1][c+1] - self.map[r,c]) <= altMax ) and (self.map[r+1][c+1] != -1):            
            actions.append((r+1,c+1))
            
        if (abs(self.map[r-1][c-1] - self.map[r,c]) <= altMax ) and (self.map[r-1][c-1]!= -1):           
            actions.append((r-1,c-1))
            
        if (abs(self.map[r-1][c+1] - self.map[r,c]) <= altMax ) and (self.map[r-1][c+1]!= -1):           
            actions.append((r-1,c+1))
            
        if (abs(self.map[r+1][c-1] - self.map[r,c]) <= altMax ) and (self.map[r+1][c-1]!= -1):             
            actions.append((r+1,c-1))
            
#        for i in range (len(self.listV)):
#            new_x = c + self.listH[i]
#            new_y = r + self.listV[i]
#            if ((abs(mars_map[new_y][new_x] - mars_map[r][c]) <= 0.25) and (mars_map[new_y][new_x]!= -1)):
#                actions.append((new_y,new_x))
            
        #print(self.map[r,c])
            
        return actions
     
    def result(self, state, action):
        return action
   
    def is_goal(self, state): 

        return state == self.goal
    
    def heuristic(self, state):
        
        x1 = state[1]
        y1 = state[0]
        x2 = self.goal[1]
        y2 = self.goal[0]
        
        distance = ((x2-x1)**2+(y2-y1)**2)**(0.5)
        #Manhattan distance on a square grid
        #abs(a-m)+abs(b-n)
        #Euclidean distance on a square frid
        #((((a-m))**2+((b-n))**2))**(1/2)
        return distance
    
    def cost (self,state,action,state2):
        return 1

#Valores iniciales y objetivo

scale = 10.0174

xi = 4000
yi = 5290

xf = 1733
yf = 10738

ri = nr - round(yi/scale)
ci = round(xi/scale)

rf = nr - round(yf/scale)
cf = round(xf/scale)

initial_state = (ri,ci)
goal_state = (rf,cf)

algorithm = breadth_first

result = algorithm(RoverSearch(initial_state, goal_state, mars_map), graph_search=True)

#Reescalado de Coordenadas

path_x = []
path_y = []
path_z = []

for i, (action, state) in enumerate(result.path()):
    path_x.append(state[1])
    path_y.append(state[0])
    path_z.append(mars_map[state[0]][state[1]])

for i in range (len(path_x)):
    path_x[i] = path_x[i]*scale
    
for i in range (len(path_y)):
    path_y[i] = (nr-path_y[i])*scale
    
# Cálculo de distancia     
distance = 0
count = 0    
for i in range (len(path_x)):
    count += 1
    if count < len(path_x):
        distance = distance + ((path_x[count]-path_x[i])**2+(path_y[count]-path_y[i])**2+(path_z[count]-path_z[i])**2)**0.5    

xfa = path_x[len(path_x)-1]
yfa = path_y[len(path_y)-1]
zfa = path_z[len(path_z)-1]

print('----------------------------------------------------------------')
print('Algoritmo utilizado: ', algorithm)
print('----------------------------------------------------------------')
print("Posición inicial del Preseverance Rover: ", '(', xi, ',', yi, ')')
print('----------------------------------------------------------------')
print("Posición objetivo: ", '(', xf, ',', yf, ')')    
print('----------------------------------------------------------------')
print("Posición alcanzada: ", '(', xfa, ',', yfa, ',', zfa, ')')
print('----------------------------------------------------------------')
print('La distancia recorrida fue de', distance, 'metros')
print('----------------------------------------------------------------')
print('El tiempo que tardó el algoritmo en llegar fue de: ', time.time() - start_time)
print('----------------------------------------------------------------')


# 3D surface print
x = scale*np.arange(mars_map.shape[1])
y = scale*np.arange(mars_map.shape[0])
X, Y = np.meshgrid(x, y)

fig = px.Figure(data = [px.Surface(x=X, y=Y, z=np.flipud(mars_map), colorscale='hot', cmin = 0, 
                           lighting = dict(ambient = 0.0, diffuse = 0.8, fresnel = 0.02, roughness = 0.4, specular = 0.2), 
                           lightposition=dict(x=0, y=nr/2, z=2*mars_map.max())),

                        px.Scatter3d(x = path_x, y = path_y, z = path_z, name='path', mode='markers',
                                    marker=dict(color = np.linspace(0, 1, len(path_x)), colorscale='Bluered', size=4))],
                
                layout = px.Layout(scene_aspectmode='manual', 
                                   scene_aspectratio=dict(x=1, y=nr/nc, z=max((mars_map.max())/x.max(), 0.2)), 
                                   scene_zaxis_range = [0,mars_map.max()])
                )

fig.show()
                                   







